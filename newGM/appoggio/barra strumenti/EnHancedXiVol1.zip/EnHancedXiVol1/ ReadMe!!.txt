� 2003-2004 by Steven W. Smith

*********************************

EnHanced Xi Vol. I

Encoded: 

ICO's - 16x128px.

*********************************

End User License:

The "EnHanced Xi Vol. I" icon set is limited to personal use. This means you may enjoy them on your computer alone without the ability to transfer, trade, or sale them for profit. Any redistribution whether it be re-zipping, extraction as PNG files, uploading to a website/forum, or adding to a compilation of other icons without prior consent from me is prohibited. This icon set is to remain intact as it was originally downloaded with the "Read Me" file.


Just as you deserve a paycheck for your daily work, so to, do I deserve a little credit for my artistic work. :)

*********************************

General Contact: iconsmithy@gmail.com // stevensmith15@comcast.net


*********************************

� 2003-2004 Smith


Get all the releases in this series containing over 600 icons:



EnHanced Xi: http://www.deviantart.com/deviation/10376985/

Xi Files: http://www.deviantart.com/deviation/10377154/

Xi'Ymbols: http://www.deviantart.com/deviation/10377339/

NIX Addicts Xi: http://www.deviantart.com/deviation/10377444/

Mac Addicts Xi: http://www.deviantart.com/deviation/10377589/

Xi Xtras vol. I: http://www.deviantart.com/deviation/10383429/

Xi Xtras vol. II: http://www.deviantart.com/deviation/10383712/

Linux PNG's: http://www.deviantart.com/deviation/10386634/

Linux Xtras: http://www.deviantart.com/deviation/10388311/

NIX Xi'Ymbols: http://www.deviantart.com/deviation/10388439/
